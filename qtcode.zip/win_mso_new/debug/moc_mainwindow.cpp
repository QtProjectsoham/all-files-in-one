/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[45];
    char stringdata0[1049];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 26), // "on_pushButton_EvPh_clicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 30), // "on_verticalSlider_valueChanged"
QT_MOC_LITERAL(4, 70, 5), // "value"
QT_MOC_LITERAL(5, 76, 28), // "on_pushButton_EstAgr_clicked"
QT_MOC_LITERAL(6, 105, 25), // "on_pushButton_LU2_clicked"
QT_MOC_LITERAL(7, 131, 25), // "on_pushButton_LU1_clicked"
QT_MOC_LITERAL(8, 157, 24), // "on_pushButton_18_clicked"
QT_MOC_LITERAL(9, 182, 24), // "on_pushButton_16_clicked"
QT_MOC_LITERAL(10, 207, 22), // "on_checkBox_11_clicked"
QT_MOC_LITERAL(11, 230, 24), // "on_pushButton_15_clicked"
QT_MOC_LITERAL(12, 255, 24), // "on_pushButton_14_clicked"
QT_MOC_LITERAL(13, 280, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(14, 305, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(15, 330, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(16, 355, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(17, 380, 24), // "on_pushButton_20_clicked"
QT_MOC_LITERAL(18, 405, 24), // "on_pushButton_21_clicked"
QT_MOC_LITERAL(19, 430, 24), // "on_pushButton_19_clicked"
QT_MOC_LITERAL(20, 455, 22), // "on_checkBox_13_clicked"
QT_MOC_LITERAL(21, 478, 21), // "on_checkBox_9_clicked"
QT_MOC_LITERAL(22, 500, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(23, 524, 21), // "on_checkBox_8_clicked"
QT_MOC_LITERAL(24, 546, 21), // "on_checkBox_6_clicked"
QT_MOC_LITERAL(25, 568, 21), // "on_checkBox_5_clicked"
QT_MOC_LITERAL(26, 590, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(27, 614, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(28, 638, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(29, 662, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(30, 686, 21), // "on_checkBox_4_clicked"
QT_MOC_LITERAL(31, 708, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(32, 732, 21), // "on_checkBox_3_clicked"
QT_MOC_LITERAL(33, 754, 21), // "on_checkBox_2_clicked"
QT_MOC_LITERAL(34, 776, 26), // "on_pushButton_test_clicked"
QT_MOC_LITERAL(35, 803, 34), // "on_horizontalSlider_c_valueCh..."
QT_MOC_LITERAL(36, 838, 34), // "on_horizontalSlider_b_valueCh..."
QT_MOC_LITERAL(37, 873, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(38, 893, 7), // "checked"
QT_MOC_LITERAL(39, 901, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(40, 923, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(41, 947, 25), // "on_spinBox_z_valueChanged"
QT_MOC_LITERAL(42, 973, 25), // "on_spinBox_y_valueChanged"
QT_MOC_LITERAL(43, 999, 25), // "on_spinBox_x_valueChanged"
QT_MOC_LITERAL(44, 1025, 23) // "on_pushButton_2_clicked"

    },
    "MainWindow\0on_pushButton_EvPh_clicked\0"
    "\0on_verticalSlider_valueChanged\0value\0"
    "on_pushButton_EstAgr_clicked\0"
    "on_pushButton_LU2_clicked\0"
    "on_pushButton_LU1_clicked\0"
    "on_pushButton_18_clicked\0"
    "on_pushButton_16_clicked\0"
    "on_checkBox_11_clicked\0on_pushButton_15_clicked\0"
    "on_pushButton_14_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_20_clicked\0"
    "on_pushButton_21_clicked\0"
    "on_pushButton_19_clicked\0"
    "on_checkBox_13_clicked\0on_checkBox_9_clicked\0"
    "on_pushButton_9_clicked\0on_checkBox_8_clicked\0"
    "on_checkBox_6_clicked\0on_checkBox_5_clicked\0"
    "on_pushButton_8_clicked\0on_pushButton_7_clicked\0"
    "on_pushButton_6_clicked\0on_pushButton_5_clicked\0"
    "on_checkBox_4_clicked\0on_pushButton_4_clicked\0"
    "on_checkBox_3_clicked\0on_checkBox_2_clicked\0"
    "on_pushButton_test_clicked\0"
    "on_horizontalSlider_c_valueChanged\0"
    "on_horizontalSlider_b_valueChanged\0"
    "on_checkBox_clicked\0checked\0"
    "on_pushButton_clicked\0on_pushButton_3_clicked\0"
    "on_spinBox_z_valueChanged\0"
    "on_spinBox_y_valueChanged\0"
    "on_spinBox_x_valueChanged\0"
    "on_pushButton_2_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      41,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  219,    2, 0x08 /* Private */,
       3,    1,  220,    2, 0x08 /* Private */,
       5,    0,  223,    2, 0x08 /* Private */,
       6,    0,  224,    2, 0x08 /* Private */,
       7,    0,  225,    2, 0x08 /* Private */,
       8,    0,  226,    2, 0x08 /* Private */,
       9,    0,  227,    2, 0x08 /* Private */,
      10,    0,  228,    2, 0x08 /* Private */,
      11,    0,  229,    2, 0x08 /* Private */,
      12,    0,  230,    2, 0x08 /* Private */,
      13,    0,  231,    2, 0x08 /* Private */,
      14,    0,  232,    2, 0x08 /* Private */,
      15,    0,  233,    2, 0x08 /* Private */,
      16,    0,  234,    2, 0x08 /* Private */,
      17,    0,  235,    2, 0x08 /* Private */,
      18,    0,  236,    2, 0x08 /* Private */,
      19,    0,  237,    2, 0x08 /* Private */,
      20,    0,  238,    2, 0x08 /* Private */,
      21,    0,  239,    2, 0x08 /* Private */,
      22,    0,  240,    2, 0x08 /* Private */,
      23,    0,  241,    2, 0x08 /* Private */,
      24,    0,  242,    2, 0x08 /* Private */,
      25,    0,  243,    2, 0x08 /* Private */,
      26,    0,  244,    2, 0x08 /* Private */,
      27,    0,  245,    2, 0x08 /* Private */,
      28,    0,  246,    2, 0x08 /* Private */,
      29,    0,  247,    2, 0x08 /* Private */,
      30,    0,  248,    2, 0x08 /* Private */,
      31,    0,  249,    2, 0x08 /* Private */,
      32,    0,  250,    2, 0x08 /* Private */,
      33,    0,  251,    2, 0x08 /* Private */,
      34,    0,  252,    2, 0x08 /* Private */,
      35,    1,  253,    2, 0x08 /* Private */,
      36,    1,  256,    2, 0x08 /* Private */,
      37,    1,  259,    2, 0x08 /* Private */,
      39,    0,  262,    2, 0x08 /* Private */,
      40,    0,  263,    2, 0x08 /* Private */,
      41,    1,  264,    2, 0x08 /* Private */,
      42,    1,  267,    2, 0x08 /* Private */,
      43,    1,  270,    2, 0x08 /* Private */,
      44,    0,  273,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_EvPh_clicked(); break;
        case 1: _t->on_verticalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_pushButton_EstAgr_clicked(); break;
        case 3: _t->on_pushButton_LU2_clicked(); break;
        case 4: _t->on_pushButton_LU1_clicked(); break;
        case 5: _t->on_pushButton_18_clicked(); break;
        case 6: _t->on_pushButton_16_clicked(); break;
        case 7: _t->on_checkBox_11_clicked(); break;
        case 8: _t->on_pushButton_15_clicked(); break;
        case 9: _t->on_pushButton_14_clicked(); break;
        case 10: _t->on_pushButton_13_clicked(); break;
        case 11: _t->on_pushButton_12_clicked(); break;
        case 12: _t->on_pushButton_11_clicked(); break;
        case 13: _t->on_pushButton_10_clicked(); break;
        case 14: _t->on_pushButton_20_clicked(); break;
        case 15: _t->on_pushButton_21_clicked(); break;
        case 16: _t->on_pushButton_19_clicked(); break;
        case 17: _t->on_checkBox_13_clicked(); break;
        case 18: _t->on_checkBox_9_clicked(); break;
        case 19: _t->on_pushButton_9_clicked(); break;
        case 20: _t->on_checkBox_8_clicked(); break;
        case 21: _t->on_checkBox_6_clicked(); break;
        case 22: _t->on_checkBox_5_clicked(); break;
        case 23: _t->on_pushButton_8_clicked(); break;
        case 24: _t->on_pushButton_7_clicked(); break;
        case 25: _t->on_pushButton_6_clicked(); break;
        case 26: _t->on_pushButton_5_clicked(); break;
        case 27: _t->on_checkBox_4_clicked(); break;
        case 28: _t->on_pushButton_4_clicked(); break;
        case 29: _t->on_checkBox_3_clicked(); break;
        case 30: _t->on_checkBox_2_clicked(); break;
        case 31: _t->on_pushButton_test_clicked(); break;
        case 32: _t->on_horizontalSlider_c_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->on_horizontalSlider_b_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->on_checkBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->on_pushButton_clicked(); break;
        case 36: _t->on_pushButton_3_clicked(); break;
        case 37: _t->on_spinBox_z_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->on_spinBox_y_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->on_spinBox_x_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->on_pushButton_2_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 41)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 41;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 41)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 41;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
