/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *sliceLabel;
    QLabel *label_h;
    QFrame *frame;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QSlider *horizontalSlider_z;
    QSpinBox *spinBox_z;
    QLabel *label_2;
    QSlider *horizontalSlider_y;
    QSpinBox *spinBox_y;
    QLabel *label_3;
    QSlider *horizontalSlider_x;
    QSpinBox *spinBox_x;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_2;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_5;
    QCheckBox *checkBox_6;
    QCheckBox *checkBox_8;
    QCheckBox *checkBox_9;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout_3;
    QSpinBox *spinBox_tap;
    QSpinBox *spinBox_ta;
    QSpinBox *spinBox_tb;
    QSpinBox *spinBox_tbp;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton_21;
    QPushButton *pushButton_20;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_20;
    QSpinBox *spinBox;
    QFrame *line_7;
    QPushButton *pushButton_test;
    QFrame *line_8;
    QPushButton *pushButton_5;
    QCheckBox *checkBox_B;
    QPushButton *pushButton_6;
    QPushButton *pushButton_15;
    QFrame *line_10;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_4;
    QCheckBox *checkBox_7;
    QPushButton *pushButton_7;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_4;
    QSlider *horizontalSlider_b;
    QLabel *label_10;
    QSlider *horizontalSlider_c;
    QLabel *label_9;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QWidget *layoutWidget5;
    QGridLayout *gridLayout_6;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *Plabel;
    QLabel *label_itn;
    QProgressBar *progressBar;
    QFrame *line_4;
    QFrame *line_5;
    QCheckBox *checkBox_14;
    QCheckBox *checkBox_15;
    QCheckBox *checkBox_16;
    QLabel *label_4;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *colLabel;
    QLabel *rowLabel;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_13;
    QCheckBox *checkBox_10;
    QPushButton *pushButton_3;
    QPushButton *pushButton_8;
    QPushButton *pushButton;
    QLabel *label_18;
    QLabel *label_19;
    QFrame *frame_2;
    QCheckBox *checkBox_11;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QLabel *GTvCnt;
    QLabel *GTbCnt;
    QPushButton *pushButton_18;
    QCheckBox *checkBox_12;
    QLabel *label_21;
    QLabel *acc;
    QRadioButton *radioButton_L;
    QRadioButton *radioButton_F;
    QPushButton *pushButton_EvPh;
    QPushButton *pushButton_12;
    QPushButton *pushButton_14;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout;
    QLabel *label_13;
    QLabel *label_16;
    QLabel *label_17;
    QSpinBox *spinBox_NML;
    QLabel *label_22;
    QSpinBox *spinBox_TA;
    QFrame *frame_3;
    QCheckBox *checkBox_RA;
    QPushButton *pushButton_LU1;
    QPushButton *pushButton_LU2;
    QPushButton *pushButton_EstAgr;
    QLabel *label_23;
    QLabel *label_Agr;
    QSlider *verticalSlider;
    QPushButton *pushButton_19;
    QPushButton *pushButton_9;
    QCheckBox *checkBox_13;
    QPushButton *pushButton_2;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QButtonGroup *buttonGroup_2;
    QButtonGroup *buttonGroup;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1211, 990);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        sliceLabel = new QLabel(centralWidget);
        sliceLabel->setObjectName(QStringLiteral("sliceLabel"));
        sliceLabel->setGeometry(QRect(10, 0, 511, 471));
        sliceLabel->setFrameShape(QFrame::Box);
        sliceLabel->setMargin(0);
        label_h = new QLabel(centralWidget);
        label_h->setObjectName(QStringLiteral("label_h"));
        label_h->setGeometry(QRect(530, 420, 491, 91));
        label_h->setAutoFillBackground(false);
        label_h->setFrameShape(QFrame::Box);
        label_h->setFrameShadow(QFrame::Raised);
        label_h->setScaledContents(true);
        frame = new QFrame(centralWidget);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(530, 20, 511, 391));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        layoutWidget = new QWidget(frame);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 10, 361, 92));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));
        QPalette palette;
        QBrush brush(QColor(0, 170, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(126, 125, 124, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label->setPalette(palette);
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setTextFormat(Qt::RichText);
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        horizontalSlider_z = new QSlider(layoutWidget);
        horizontalSlider_z->setObjectName(QStringLiteral("horizontalSlider_z"));
        horizontalSlider_z->setMinimum(1);
        horizontalSlider_z->setMaximum(512);
        horizontalSlider_z->setValue(100);
        horizontalSlider_z->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSlider_z, 0, 1, 1, 1);

        spinBox_z = new QSpinBox(layoutWidget);
        spinBox_z->setObjectName(QStringLiteral("spinBox_z"));
        spinBox_z->setMinimum(1);
        spinBox_z->setMaximum(512);
        spinBox_z->setValue(100);

        gridLayout->addWidget(spinBox_z, 0, 2, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QPalette palette1;
        QBrush brush2(QColor(255, 0, 0, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_2->setPalette(palette1);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        horizontalSlider_y = new QSlider(layoutWidget);
        horizontalSlider_y->setObjectName(QStringLiteral("horizontalSlider_y"));
        horizontalSlider_y->setMinimum(1);
        horizontalSlider_y->setMaximum(512);
        horizontalSlider_y->setValue(100);
        horizontalSlider_y->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSlider_y, 1, 1, 1, 1);

        spinBox_y = new QSpinBox(layoutWidget);
        spinBox_y->setObjectName(QStringLiteral("spinBox_y"));
        spinBox_y->setMinimum(1);
        spinBox_y->setMaximum(512);
        spinBox_y->setValue(100);

        gridLayout->addWidget(spinBox_y, 1, 2, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        QPalette palette2;
        QBrush brush3(QColor(0, 0, 255, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush3);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush3);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_3->setPalette(palette2);
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        horizontalSlider_x = new QSlider(layoutWidget);
        horizontalSlider_x->setObjectName(QStringLiteral("horizontalSlider_x"));
        horizontalSlider_x->setMinimum(1);
        horizontalSlider_x->setMaximum(512);
        horizontalSlider_x->setValue(100);
        horizontalSlider_x->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSlider_x, 2, 1, 1, 1);

        spinBox_x = new QSpinBox(layoutWidget);
        spinBox_x->setObjectName(QStringLiteral("spinBox_x"));
        spinBox_x->setMinimum(1);
        spinBox_x->setMaximum(512);
        spinBox_x->setValue(100);

        gridLayout->addWidget(spinBox_x, 2, 2, 1, 1);

        layoutWidget1 = new QWidget(frame);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(3, 111, 125, 258));
        gridLayout_2 = new QGridLayout(layoutWidget1);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        checkBox_3 = new QCheckBox(layoutWidget1);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));

        gridLayout_2->addWidget(checkBox_3, 4, 0, 1, 1);

        checkBox_2 = new QCheckBox(layoutWidget1);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));

        gridLayout_2->addWidget(checkBox_2, 3, 0, 1, 1);

        checkBox = new QCheckBox(layoutWidget1);
        checkBox->setObjectName(QStringLiteral("checkBox"));

        gridLayout_2->addWidget(checkBox, 1, 0, 1, 1);

        checkBox_4 = new QCheckBox(layoutWidget1);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));

        gridLayout_2->addWidget(checkBox_4, 5, 0, 1, 1);

        checkBox_5 = new QCheckBox(layoutWidget1);
        checkBox_5->setObjectName(QStringLiteral("checkBox_5"));

        gridLayout_2->addWidget(checkBox_5, 6, 0, 1, 1);

        checkBox_6 = new QCheckBox(layoutWidget1);
        checkBox_6->setObjectName(QStringLiteral("checkBox_6"));

        gridLayout_2->addWidget(checkBox_6, 0, 0, 1, 1);

        checkBox_8 = new QCheckBox(layoutWidget1);
        checkBox_8->setObjectName(QStringLiteral("checkBox_8"));

        gridLayout_2->addWidget(checkBox_8, 7, 0, 1, 1);

        checkBox_9 = new QCheckBox(layoutWidget1);
        checkBox_9->setObjectName(QStringLiteral("checkBox_9"));

        gridLayout_2->addWidget(checkBox_9, 2, 0, 1, 1);

        layoutWidget2 = new QWidget(frame);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(133, 111, 242, 51));
        gridLayout_3 = new QGridLayout(layoutWidget2);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        spinBox_tap = new QSpinBox(layoutWidget2);
        spinBox_tap->setObjectName(QStringLiteral("spinBox_tap"));
        spinBox_tap->setMinimum(0);
        spinBox_tap->setMaximum(3000);
        spinBox_tap->setValue(130);

        gridLayout_3->addWidget(spinBox_tap, 0, 0, 1, 1);

        spinBox_ta = new QSpinBox(layoutWidget2);
        spinBox_ta->setObjectName(QStringLiteral("spinBox_ta"));
        spinBox_ta->setMaximum(3000);
        spinBox_ta->setSingleStep(1);
        spinBox_ta->setValue(325);

        gridLayout_3->addWidget(spinBox_ta, 0, 1, 1, 1);

        spinBox_tb = new QSpinBox(layoutWidget2);
        spinBox_tb->setObjectName(QStringLiteral("spinBox_tb"));
        spinBox_tb->setMaximum(3000);
        spinBox_tb->setValue(500);

        gridLayout_3->addWidget(spinBox_tb, 0, 2, 1, 1);

        spinBox_tbp = new QSpinBox(layoutWidget2);
        spinBox_tbp->setObjectName(QStringLiteral("spinBox_tbp"));
        spinBox_tbp->setMaximum(3000);
        spinBox_tbp->setValue(2500);

        gridLayout_3->addWidget(spinBox_tbp, 0, 3, 1, 1);

        label_5 = new QLabel(layoutWidget2);
        label_5->setObjectName(QStringLiteral("label_5"));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush3);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush3);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_5->setPalette(palette3);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_5, 1, 0, 1, 1);

        label_6 = new QLabel(layoutWidget2);
        label_6->setObjectName(QStringLiteral("label_6"));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_6->setPalette(palette4);
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_6, 1, 1, 1, 1);

        label_7 = new QLabel(layoutWidget2);
        label_7->setObjectName(QStringLiteral("label_7"));
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_7->setPalette(palette5);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_7, 1, 2, 1, 1);

        label_8 = new QLabel(layoutWidget2);
        label_8->setObjectName(QStringLiteral("label_8"));
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::WindowText, brush3);
        palette6.setBrush(QPalette::Inactive, QPalette::WindowText, brush3);
        palette6.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_8->setPalette(palette6);
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_8, 1, 3, 1, 1);

        layoutWidget3 = new QWidget(frame);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(373, 11, 176, 377));
        gridLayout_5 = new QGridLayout(layoutWidget3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton_21 = new QPushButton(layoutWidget3);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));

        gridLayout_5->addWidget(pushButton_21, 10, 0, 1, 1);

        pushButton_20 = new QPushButton(layoutWidget3);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));

        gridLayout_5->addWidget(pushButton_20, 5, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_20 = new QLabel(layoutWidget3);
        label_20->setObjectName(QStringLiteral("label_20"));

        horizontalLayout_2->addWidget(label_20);

        spinBox = new QSpinBox(layoutWidget3);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setMaximum(500);
        spinBox->setValue(50);

        horizontalLayout_2->addWidget(spinBox);


        gridLayout_5->addLayout(horizontalLayout_2, 6, 0, 1, 1);

        line_7 = new QFrame(layoutWidget3);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        gridLayout_5->addWidget(line_7, 4, 0, 1, 1);

        pushButton_test = new QPushButton(layoutWidget3);
        pushButton_test->setObjectName(QStringLiteral("pushButton_test"));

        gridLayout_5->addWidget(pushButton_test, 8, 0, 1, 1);

        line_8 = new QFrame(layoutWidget3);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        gridLayout_5->addWidget(line_8, 7, 0, 1, 1);

        pushButton_5 = new QPushButton(layoutWidget3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::Text, brush2);
        QBrush brush4(QColor(205, 0, 0, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette7.setBrush(QPalette::Active, QPalette::ButtonText, brush4);
        palette7.setBrush(QPalette::Inactive, QPalette::Text, brush2);
        palette7.setBrush(QPalette::Inactive, QPalette::ButtonText, brush4);
        palette7.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        palette7.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        pushButton_5->setPalette(palette7);

        gridLayout_5->addWidget(pushButton_5, 1, 0, 1, 1);

        checkBox_B = new QCheckBox(layoutWidget3);
        checkBox_B->setObjectName(QStringLiteral("checkBox_B"));

        gridLayout_5->addWidget(checkBox_B, 17, 0, 1, 1);

        pushButton_6 = new QPushButton(layoutWidget3);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        pushButton_6->setPalette(palette8);

        gridLayout_5->addWidget(pushButton_6, 3, 0, 1, 1);

        pushButton_15 = new QPushButton(layoutWidget3);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));

        gridLayout_5->addWidget(pushButton_15, 16, 0, 1, 1);

        line_10 = new QFrame(layoutWidget3);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setFrameShape(QFrame::HLine);
        line_10->setFrameShadow(QFrame::Sunken);

        gridLayout_5->addWidget(line_10, 15, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButton_4 = new QPushButton(layoutWidget3);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setEnabled(true);

        verticalLayout->addWidget(pushButton_4);

        checkBox_7 = new QCheckBox(layoutWidget3);
        checkBox_7->setObjectName(QStringLiteral("checkBox_7"));
        checkBox_7->setEnabled(true);

        verticalLayout->addWidget(checkBox_7);


        gridLayout_5->addLayout(verticalLayout, 9, 0, 1, 1);

        pushButton_7 = new QPushButton(layoutWidget3);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        QPalette palette9;
        QBrush brush5(QColor(0, 85, 255, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        pushButton_7->setPalette(palette9);

        gridLayout_5->addWidget(pushButton_7, 2, 0, 1, 1);

        layoutWidget4 = new QWidget(frame);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(133, 271, 231, 71));
        gridLayout_4 = new QGridLayout(layoutWidget4);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalSlider_b = new QSlider(layoutWidget4);
        horizontalSlider_b->setObjectName(QStringLiteral("horizontalSlider_b"));
        horizontalSlider_b->setMinimum(-127);
        horizontalSlider_b->setMaximum(127);
        horizontalSlider_b->setOrientation(Qt::Horizontal);

        gridLayout_4->addWidget(horizontalSlider_b, 0, 1, 1, 1);

        label_10 = new QLabel(layoutWidget4);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_4->addWidget(label_10, 5, 0, 1, 1);

        horizontalSlider_c = new QSlider(layoutWidget4);
        horizontalSlider_c->setObjectName(QStringLiteral("horizontalSlider_c"));
        horizontalSlider_c->setMinimum(-100);
        horizontalSlider_c->setMaximum(99);
        horizontalSlider_c->setOrientation(Qt::Horizontal);

        gridLayout_4->addWidget(horizontalSlider_c, 5, 1, 1, 1);

        label_9 = new QLabel(layoutWidget4);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_4->addWidget(label_9, 0, 0, 1, 1);

        line = new QFrame(frame);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(131, 163, 241, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(frame);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(3, 96, 371, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(frame);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(360, 11, 16, 301));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        layoutWidget5 = new QWidget(frame);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(133, 181, 268, 41));
        gridLayout_6 = new QGridLayout(layoutWidget5);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(layoutWidget5);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_6->addWidget(label_11, 0, 0, 1, 1);

        label_12 = new QLabel(layoutWidget5);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setFont(font);

        gridLayout_6->addWidget(label_12, 0, 1, 1, 1);

        Plabel = new QLabel(layoutWidget5);
        Plabel->setObjectName(QStringLiteral("Plabel"));

        gridLayout_6->addWidget(Plabel, 1, 0, 1, 1);

        label_itn = new QLabel(layoutWidget5);
        label_itn->setObjectName(QStringLiteral("label_itn"));

        gridLayout_6->addWidget(label_itn, 1, 1, 1, 1);

        progressBar = new QProgressBar(frame);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(133, 231, 231, 21));
        progressBar->setValue(0);
        line_4 = new QFrame(frame);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(134, 251, 241, 20));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        line_5 = new QFrame(frame);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setGeometry(QRect(120, 110, 16, 201));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        checkBox_14 = new QCheckBox(frame);
        checkBox_14->setObjectName(QStringLiteral("checkBox_14"));
        checkBox_14->setGeometry(QRect(140, 350, 70, 17));
        checkBox_15 = new QCheckBox(frame);
        checkBox_15->setObjectName(QStringLiteral("checkBox_15"));
        checkBox_15->setGeometry(QRect(230, 350, 41, 17));
        checkBox_16 = new QCheckBox(frame);
        checkBox_16->setObjectName(QStringLiteral("checkBox_16"));
        checkBox_16->setGeometry(QRect(320, 350, 41, 17));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(1080, 660, 52, 16));
        label_14 = new QLabel(centralWidget);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(1080, 710, 52, 15));
        label_15 = new QLabel(centralWidget);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(1080, 730, 52, 15));
        colLabel = new QLabel(centralWidget);
        colLabel->setObjectName(QStringLiteral("colLabel"));
        colLabel->setGeometry(QRect(530, 520, 513, 441));
        colLabel->setFrameShape(QFrame::Box);
        colLabel->setScaledContents(true);
        rowLabel = new QLabel(centralWidget);
        rowLabel->setObjectName(QStringLiteral("rowLabel"));
        rowLabel->setGeometry(QRect(10, 520, 513, 441));
        rowLabel->setFrameShape(QFrame::Box);
        rowLabel->setScaledContents(true);
        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(1060, 630, 96, 24));
        pushButton_11 = new QPushButton(centralWidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(1090, 910, 96, 24));
        pushButton_13 = new QPushButton(centralWidget);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(1090, 930, 96, 24));
        checkBox_10 = new QCheckBox(centralWidget);
        checkBox_10->setObjectName(QStringLiteral("checkBox_10"));
        checkBox_10->setGeometry(QRect(1060, 860, 71, 23));
        checkBox_10->setChecked(false);
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setEnabled(false);
        pushButton_3->setGeometry(QRect(1060, 840, 129, 24));
        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setEnabled(false);
        pushButton_8->setGeometry(QRect(1060, 820, 131, 24));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(1060, 800, 129, 24));
        label_18 = new QLabel(centralWidget);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(540, 0, 61, 16));
        label_18->setFont(font);
        label_19 = new QLabel(centralWidget);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(610, 0, 22, 13));
        frame_2 = new QFrame(centralWidget);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        frame_2->setGeometry(QRect(1050, 50, 141, 311));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        checkBox_11 = new QCheckBox(frame_2);
        checkBox_11->setObjectName(QStringLiteral("checkBox_11"));
        checkBox_11->setGeometry(QRect(7, 10, 131, 23));
        radioButton = new QRadioButton(frame_2);
        buttonGroup_2 = new QButtonGroup(MainWindow);
        buttonGroup_2->setObjectName(QStringLiteral("buttonGroup_2"));
        buttonGroup_2->addButton(radioButton);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(12, 100, 93, 21));
        QPalette palette10;
        QBrush brush6(QColor(191, 191, 0, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette10.setBrush(QPalette::Active, QPalette::ButtonText, brush6);
        palette10.setBrush(QPalette::Inactive, QPalette::ButtonText, brush6);
        palette10.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        radioButton->setPalette(palette10);
        radioButton->setFont(font);
        radioButton_2 = new QRadioButton(frame_2);
        buttonGroup_2->addButton(radioButton_2);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(12, 120, 93, 21));
        QPalette palette11;
        QBrush brush7(QColor(0, 179, 179, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette11.setBrush(QPalette::Active, QPalette::ButtonText, brush7);
        palette11.setBrush(QPalette::Inactive, QPalette::ButtonText, brush7);
        palette11.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        radioButton_2->setPalette(palette11);
        radioButton_2->setFont(font);
        pushButton_16 = new QPushButton(frame_2);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(8, 147, 61, 24));
        pushButton_17 = new QPushButton(frame_2);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(70, 147, 61, 24));
        GTvCnt = new QLabel(frame_2);
        GTvCnt->setObjectName(QStringLiteral("GTvCnt"));
        GTvCnt->setGeometry(QRect(100, 100, 41, 20));
        GTbCnt = new QLabel(frame_2);
        GTbCnt->setObjectName(QStringLiteral("GTbCnt"));
        GTbCnt->setGeometry(QRect(100, 120, 41, 20));
        pushButton_18 = new QPushButton(frame_2);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(10, 177, 121, 24));
        checkBox_12 = new QCheckBox(frame_2);
        checkBox_12->setObjectName(QStringLiteral("checkBox_12"));
        checkBox_12->setGeometry(QRect(7, 74, 121, 23));
        label_21 = new QLabel(frame_2);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(20, 215, 81, 21));
        acc = new QLabel(frame_2);
        acc->setObjectName(QStringLiteral("acc"));
        acc->setGeometry(QRect(98, 215, 31, 20));
        radioButton_L = new QRadioButton(frame_2);
        buttonGroup = new QButtonGroup(MainWindow);
        buttonGroup->setObjectName(QStringLiteral("buttonGroup"));
        buttonGroup->addButton(radioButton_L);
        radioButton_L->setObjectName(QStringLiteral("radioButton_L"));
        radioButton_L->setGeometry(QRect(20, 32, 93, 21));
        radioButton_L->setChecked(true);
        radioButton_F = new QRadioButton(frame_2);
        buttonGroup->addButton(radioButton_F);
        radioButton_F->setObjectName(QStringLiteral("radioButton_F"));
        radioButton_F->setGeometry(QRect(20, 52, 93, 21));
        pushButton_EvPh = new QPushButton(frame_2);
        pushButton_EvPh->setObjectName(QStringLiteral("pushButton_EvPh"));
        pushButton_EvPh->setGeometry(QRect(10, 250, 121, 24));
        pushButton_12 = new QPushButton(frame_2);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(10, 280, 121, 23));
        pushButton_14 = new QPushButton(centralWidget);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(1062, 780, 121, 24));
        layoutWidget6 = new QWidget(centralWidget);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(1059, 680, 121, 20));
        horizontalLayout = new QHBoxLayout(layoutWidget6);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_13 = new QLabel(layoutWidget6);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout->addWidget(label_13);

        label_16 = new QLabel(layoutWidget6);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout->addWidget(label_16);

        label_17 = new QLabel(layoutWidget6);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout->addWidget(label_17);

        spinBox_NML = new QSpinBox(centralWidget);
        spinBox_NML->setObjectName(QStringLiteral("spinBox_NML"));
        spinBox_NML->setGeometry(QRect(1120, 860, 61, 25));
        spinBox_NML->setValue(2);
        label_22 = new QLabel(centralWidget);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(1050, 536, 91, 16));
        spinBox_TA = new QSpinBox(centralWidget);
        spinBox_TA->setObjectName(QStringLiteral("spinBox_TA"));
        spinBox_TA->setGeometry(QRect(1138, 530, 54, 25));
        spinBox_TA->setMaximum(512);
        frame_3 = new QFrame(centralWidget);
        frame_3->setObjectName(QStringLiteral("frame_3"));
        frame_3->setGeometry(QRect(1050, 370, 141, 151));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        checkBox_RA = new QCheckBox(frame_3);
        checkBox_RA->setObjectName(QStringLiteral("checkBox_RA"));
        checkBox_RA->setGeometry(QRect(10, 10, 121, 23));
        pushButton_LU1 = new QPushButton(frame_3);
        pushButton_LU1->setObjectName(QStringLiteral("pushButton_LU1"));
        pushButton_LU1->setGeometry(QRect(10, 40, 121, 24));
        pushButton_LU2 = new QPushButton(frame_3);
        pushButton_LU2->setObjectName(QStringLiteral("pushButton_LU2"));
        pushButton_LU2->setGeometry(QRect(10, 60, 121, 24));
        pushButton_EstAgr = new QPushButton(frame_3);
        pushButton_EstAgr->setObjectName(QStringLiteral("pushButton_EstAgr"));
        pushButton_EstAgr->setGeometry(QRect(10, 90, 121, 24));
        label_23 = new QLabel(frame_3);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(17, 120, 71, 16));
        label_Agr = new QLabel(frame_3);
        label_Agr->setObjectName(QStringLiteral("label_Agr"));
        label_Agr->setGeometry(QRect(85, 121, 52, 15));
        verticalSlider = new QSlider(centralWidget);
        verticalSlider->setObjectName(QStringLiteral("verticalSlider"));
        verticalSlider->setGeometry(QRect(1020, 420, 23, 91));
        verticalSlider->setMinimum(1);
        verticalSlider->setMaximum(200);
        verticalSlider->setPageStep(2);
        verticalSlider->setValue(1);
        verticalSlider->setOrientation(Qt::Vertical);
        pushButton_19 = new QPushButton(centralWidget);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(1070, 580, 87, 27));
        pushButton_9 = new QPushButton(centralWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(1060, 750, 131, 23));
        checkBox_13 = new QCheckBox(centralWidget);
        checkBox_13->setObjectName(QStringLiteral("checkBox_13"));
        checkBox_13->setGeometry(QRect(1060, 360, 101, 17));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(1050, 30, 151, 23));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(spinBox_tap, SIGNAL(valueChanged(int)), pushButton, SLOT(click()));
        QObject::connect(spinBox_ta, SIGNAL(valueChanged(int)), pushButton, SLOT(click()));
        QObject::connect(spinBox_tb, SIGNAL(valueChanged(int)), pushButton, SLOT(click()));
        QObject::connect(spinBox_tbp, SIGNAL(valueChanged(int)), pushButton, SLOT(click()));
        QObject::connect(spinBox_x, SIGNAL(valueChanged(int)), horizontalSlider_x, SLOT(setValue(int)));
        QObject::connect(horizontalSlider_x, SIGNAL(valueChanged(int)), spinBox_x, SLOT(setValue(int)));
        QObject::connect(horizontalSlider_y, SIGNAL(valueChanged(int)), spinBox_y, SLOT(setValue(int)));
        QObject::connect(spinBox_y, SIGNAL(valueChanged(int)), horizontalSlider_y, SLOT(setValue(int)));
        QObject::connect(horizontalSlider_z, SIGNAL(valueChanged(int)), spinBox_z, SLOT(setValue(int)));
        QObject::connect(spinBox_z, SIGNAL(valueChanged(int)), horizontalSlider_z, SLOT(setValue(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "CTA Image Analysis", 0));
        sliceLabel->setText(QString());
        label_h->setText(QString());
        label->setText(QApplication::translate("MainWindow", "Slice (Z axis):", 0));
        label_2->setText(QApplication::translate("MainWindow", "Row (Y axis):", 0));
        label_3->setText(QApplication::translate("MainWindow", "Column (X axis):", 0));
        checkBox_3->setText(QApplication::translate("MainWindow", " Show FDT ", 0));
        checkBox_2->setText(QApplication::translate("MainWindow", "Show Grdlines", 0));
        checkBox->setText(QApplication::translate("MainWindow", "Fuzzy Segment", 0));
        checkBox_4->setText(QApplication::translate("MainWindow", "Show FC", 0));
        checkBox_5->setText(QApplication::translate("MainWindow", "Show MR", 0));
        checkBox_6->setText(QApplication::translate("MainWindow", "Show Seed/Sep", 0));
        checkBox_8->setText(QApplication::translate("MainWindow", "Remove Bone", 0));
        checkBox_9->setText(QApplication::translate("MainWindow", "Core Vessel", 0));
        label_5->setText(QApplication::translate("MainWindow", "ta_p", 0));
        label_6->setText(QApplication::translate("MainWindow", "ta", 0));
        label_7->setText(QApplication::translate("MainWindow", "tb", 0));
        label_8->setText(QApplication::translate("MainWindow", "tb_p", 0));
        pushButton_21->setText(QApplication::translate("MainWindow", "NEW Core Vessel", 0));
        pushButton_20->setText(QApplication::translate("MainWindow", "Core Vessel seeds", 0));
        label_20->setText(QApplication::translate("MainWindow", "Erosion :", 0));
        pushButton_test->setText(QApplication::translate("MainWindow", "FDT-LMLS-FCMR", 0));
        pushButton_5->setText(QApplication::translate("MainWindow", "Add V-Seed", 0));
        checkBox_B->setText(QApplication::translate("MainWindow", "With Bone", 0));
        pushButton_6->setText(QApplication::translate("MainWindow", "Add B-Seed", 0));
        pushButton_15->setText(QApplication::translate("MainWindow", "Write Image", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "FCMR", 0));
        checkBox_7->setText(QApplication::translate("MainWindow", "Iterate", 0));
        pushButton_7->setText(QApplication::translate("MainWindow", "Add Separator", 0));
        label_10->setText(QApplication::translate("MainWindow", "Contrast:", 0));
        label_9->setText(QApplication::translate("MainWindow", "Brightness:", 0));
        label_11->setText(QApplication::translate("MainWindow", "Grey Scale Value/Update count:", 0));
        label_12->setText(QApplication::translate("MainWindow", "0", 0));
        Plabel->setText(QApplication::translate("MainWindow", "Progress Bar:                                           ", 0));
        label_itn->setText(QApplication::translate("MainWindow", "1", 0));
        checkBox_14->setText(QApplication::translate("MainWindow", "sep", 0));
        checkBox_15->setText(QApplication::translate("MainWindow", "jp", 0));
        checkBox_16->setText(QApplication::translate("MainWindow", "dp", 0));
        label_4->setText(QApplication::translate("MainWindow", "Debug-1", 0));
        label_14->setText(QApplication::translate("MainWindow", "Degug-2", 0));
        label_15->setText(QApplication::translate("MainWindow", "Debug-3", 0));
        colLabel->setText(QString());
        rowLabel->setText(QString());
        pushButton_10->setText(QApplication::translate("MainWindow", "Erosion", 0));
        pushButton_11->setText(QApplication::translate("MainWindow", "Dialation", 0));
        pushButton_13->setText(QApplication::translate("MainWindow", "Bone NML", 0));
        checkBox_10->setText(QApplication::translate("MainWindow", "NML", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "Compute LM-LS", 0));
        pushButton_8->setText(QApplication::translate("MainWindow", "Compute MR", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Load Histogram", 0));
        label_18->setText(QApplication::translate("MainWindow", "Filename:", 0));
        label_19->setText(QApplication::translate("MainWindow", "Path", 0));
        checkBox_11->setText(QApplication::translate("MainWindow", "Enable GT Module", 0));
        radioButton->setText(QApplication::translate("MainWindow", "GT Vessel", 0));
        radioButton_2->setText(QApplication::translate("MainWindow", "GT Bone", 0));
        pushButton_16->setText(QApplication::translate("MainWindow", "Show", 0));
        pushButton_17->setText(QApplication::translate("MainWindow", "Erase", 0));
        GTvCnt->setText(QApplication::translate("MainWindow", "0", 0));
        GTbCnt->setText(QApplication::translate("MainWindow", "0", 0));
        pushButton_18->setText(QApplication::translate("MainWindow", "Evaluate", 0));
        checkBox_12->setText(QApplication::translate("MainWindow", "Enable 4-N", 0));
        label_21->setText(QApplication::translate("MainWindow", "Accuracy (%):", 0));
        acc->setText(QApplication::translate("MainWindow", "0", 0));
        radioButton_L->setText(QApplication::translate("MainWindow", "Large Scale", 0));
        radioButton_F->setText(QApplication::translate("MainWindow", "Finer Scale", 0));
        pushButton_EvPh->setText(QApplication::translate("MainWindow", "Evaluate Phantom", 0));
        pushButton_12->setText(QApplication::translate("MainWindow", "Core Vessel", 0));
        pushButton_14->setText(QApplication::translate("MainWindow", "Reset", 0));
        label_13->setText(QApplication::translate("MainWindow", "S", 0));
        label_16->setText(QApplication::translate("MainWindow", "R", 0));
        label_17->setText(QApplication::translate("MainWindow", "C", 0));
        label_22->setText(QApplication::translate("MainWindow", "TA upto Slice No.", 0));
        checkBox_RA->setText(QApplication::translate("MainWindow", "Repro Analysis", 0));
        pushButton_LU1->setText(QApplication::translate("MainWindow", "Load User-1", 0));
        pushButton_LU2->setText(QApplication::translate("MainWindow", "Load User-2", 0));
        pushButton_EstAgr->setText(QApplication::translate("MainWindow", "Estimate Agreement", 0));
        label_23->setText(QApplication::translate("MainWindow", "Agreement:", 0));
        label_Agr->setText(QApplication::translate("MainWindow", "0", 0));
        pushButton_19->setText(QApplication::translate("MainWindow", "Erode PV", 0));
        pushButton_9->setText(QApplication::translate("MainWindow", "VTKdisplay", 0));
        checkBox_13->setText(QApplication::translate("MainWindow", "Core Detection", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Load Image", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
